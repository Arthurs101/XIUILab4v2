package com.example.dicerollerapp

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast

class MainActivity : AppCompatActivity() {


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val Roller: Button =  findViewById(R.id.RollerButton)
        val sixSides = Dice(1..6)
        val Displayer: ImageView = findViewById(R.id.DiceDisplay)
        Roller.setOnClickListener{
            val popup = Toast.makeText(this,"Dice Rolled",Toast.LENGTH_SHORT)
            popup.show()
            val texter: TextView = findViewById(R.id.Displayer)
            val result:  Int = sixSides.roll()
            texter.text = getString(R.string.result) + "${result}"
            //llamar la funcion para setear la imagen correcta
            Dicesetter(result,Displayer)

        }
    }

}



//para colocar la imagen indicada
fun Dicesetter(result: Int, Display: ImageView){
    when(result){
        1 -> Display.setImageResource(R.drawable.dice_1)
        2 -> Display.setImageResource(R.drawable.dice_2)
        3 -> Display.setImageResource(R.drawable.dice_3)
        4 -> Display.setImageResource(R.drawable.dice_4)
        5 -> Display.setImageResource(R.drawable.dice_5)
        6 -> Display.setImageResource(R.drawable.dice_6)
    }
}
class Dice(val range: IntRange){
    //crear numero random del rango que tenga
    fun roll():Int {
        val dicerange = range
        return dicerange.random()
    }
}